
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kirckurs',
  applicationName: 'gruppe2-endpoint',
  appUid: 'Y93VHvJVRMFqTt66v5',
  orgUid: '79d11953-78fc-45d7-be05-d3d887fc8ff1',
  deploymentUid: '7e71a455-7328-4c42-9fd6-b97cbe91487a',
  serviceName: 'gruppe2-endpoint',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'gruppe2-endpoint-dev-get-messages', timeout: 6 };

try {
  const userHandler = require('./dynamodb.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getMessage, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}